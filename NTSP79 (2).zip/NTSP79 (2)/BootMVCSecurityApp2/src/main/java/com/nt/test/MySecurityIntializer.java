package com.nt.test;

import org.springframework.security.web.context.AbstractSecurityWebApplicationInitializer;

public class MySecurityIntializer extends AbstractSecurityWebApplicationInitializer {

}
