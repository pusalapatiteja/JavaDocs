package com.nt.service;

public interface EmployeeService {
	public int fetchEmpsCount()throws Exception;

}
