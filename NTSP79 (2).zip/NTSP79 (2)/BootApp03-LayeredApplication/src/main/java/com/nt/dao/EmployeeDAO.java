package com.nt.dao;

public interface EmployeeDAO {
	public int getEmpsCount()throws Exception;

}
