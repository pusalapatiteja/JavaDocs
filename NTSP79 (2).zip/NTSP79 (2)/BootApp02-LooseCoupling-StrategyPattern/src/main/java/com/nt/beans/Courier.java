package com.nt.beans;

public interface Courier {
   public void deliver(int oid);
}
