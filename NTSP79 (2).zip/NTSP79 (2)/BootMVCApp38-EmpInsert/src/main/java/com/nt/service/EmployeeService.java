package com.nt.service;

import com.nt.dto.EmployeeDTO;

public interface EmployeeService {
   public String register(EmployeeDTO dto);
}
