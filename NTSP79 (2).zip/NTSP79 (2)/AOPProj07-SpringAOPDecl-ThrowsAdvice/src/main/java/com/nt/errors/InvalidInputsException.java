package com.nt.errors;

public class InvalidInputsException extends RuntimeException {
	public InvalidInputsException(String msg) {
		super(msg);
	}

}
