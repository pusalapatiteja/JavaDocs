package com.nt.service;

import com.nt.dto.StudentDTO;

public interface StudentService {
	public  String register(StudentDTO dto);

}
