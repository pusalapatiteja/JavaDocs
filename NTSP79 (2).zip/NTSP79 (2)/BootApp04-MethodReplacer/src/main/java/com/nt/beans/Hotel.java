package com.nt.beans;

public class Hotel {
	public  float calHotelPrice(float basePrice){
		System.out.println("Hotel Booking price:: calNormalHotelPrice");
		return (basePrice);
	}
}
