package com.nt.service;

public class OnLineShoppingStore {
	
	public  float  shopping(String[] items){
		float billAmt=0.0f;
		billAmt=items.length*1000;
		return billAmt;
	}

}
