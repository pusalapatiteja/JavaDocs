package com.nt.service;

public interface ArithmeticOpeationsInterface {
	public int add(int x,int y);
	public int sub(int x,int y);
	public int mul(int x,int y);
	public int div(int x,int y);

}
